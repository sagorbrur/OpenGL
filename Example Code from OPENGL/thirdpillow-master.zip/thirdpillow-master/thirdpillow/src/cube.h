#ifndef CUBE_H_
#define CUBE_H_

#endif