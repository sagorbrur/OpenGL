/*
 * world.cpp
 *
 *  Created on: Apr 8, 2014
 *      Author: jwpilly
 */

#include "world.h"

world::world() {

}

world::~world() {

}

