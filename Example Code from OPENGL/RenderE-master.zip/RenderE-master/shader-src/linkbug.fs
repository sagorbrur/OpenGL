varying vec4 normal;

void main(){
    gl_FragColor = normal;
}